<!--border-->
	<div class="row">
		<div class=" col-md-12 col-sm-12 col-xs-12 border">
			 
		</div>
	</div>

	<!--body-->
	<div class="row" onload="setup()">
		<div class=" col-md-12 col-sm-12 col-lg-12 body " > 
		<div class="container">
			<div class="h">
				<h1>Integrated Research and Training Center (IRTC)</h1>
				<h3><i>&nbsp;&nbsp;Departments</i></h3>
					<ul><h3><p onclick="$('#audiovisual').toggle()" class="o2">Audio Visual Department</p></h3>
						<div class="collapse off" id="audiovisual" style="margin-left:40px;">
							<br/><br/>
							<p><b>Head:</b><!-- name ng head ng dept. --></p>
							<p><b>Employees:</b>
								<ol>
									<li>Employee 1</li>
									<li>Employee 2</li>
									<li>Employee 3</li>
								<ol>
							</p>
						</div>
					</ul><br/>
					<ul><h3><p onclick="$('#computer').toggle()" class="o2">Computer Department</p></h3>
						<div class="collapse off" id="computer" style="margin-left:40px;">
							<br/><br/>
							<p><b>Head:</b><!-- name ng head ng dept. --></p>
							<p><b>Employees:</b>
								<ol>
									<li>Employee 1</li>
									<li>Employee 2</li>
									<li>Employee 3</li>
								<ol>
							</p>
						</div>
					</ul><br/>
					<ul><h3><p onclick="$('#construction').toggle()" class="o2">Construction Engineering and Management Department</p></h3>
						<div class="collapse off" id="construction" style="margin-left:40px;">
							<br/><br/>
							<p><b>Head:</b><!-- name ng head ng dept. --></p>
							<p><b>Employees:</b>
								<ol>
									<li>Employee 1</li>
									<li>Employee 2</li>
								<ol>
							</p>
						</div>
					</ul><br/>
					<ul><h3><p onclick="$('#electrical').toggle()" class="o2">Electrical Department</p></h3>
						<div class="collapse off" id="electrical" style="margin-left:40px;">
							<br/><br/>
							<p><b>Head:</b><!-- name ng head ng dept. --></p>
							<p><b>Employees:</b>
								<ol>
									<li>Employee 1</li>
									<li>Employee 2</li>
								<ol>
							</p>
						</div>
					</ul><br/>
			</div>
		
		</div>


	</div>
</div>
	<!--border-->
	<div class="row">
		<div class=" col-md-12 col-sm-12 col-xs-12 border">  
		</div>
	</div>