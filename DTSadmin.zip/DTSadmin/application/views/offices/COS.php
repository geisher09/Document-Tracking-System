<!--border-->
	<div class="row">
		<div class=" col-md-12 col-sm-12 col-xs-12 border">
			 
		</div>
	</div>

	<!--body-->
	<div class="row" onload="setup()">
		<div class=" col-md-12 col-sm-12 col-lg-12 body " > 
		<div class="container">
			<div class="h">
				<h1>College Of Science (COS)</h1>
				<h3><i>&nbsp;&nbsp;Departments</i></h3>
					<ul><h3><p onclick="$('#cosdean').toggle()" class="o2">Dean's Office</p></h3>
						<div class="collapse off" id="cosdean" style="margin-left:40px;">
							<br/><br/>
							<p><b>Head:</b><!-- name ng head ng dept. --></p>
							<p><b>Employees:</b>
								<ol>
									<li>Employee 1</li>
									<li>Employee 2</li>
								<ol>
							</p>
						</div>
					</ul><br/>
					<ul><h3><p onclick="$('#cosmath').toggle()" class="o2">Math Department</p></h3>
						<div class="collapse off" id="cosmath" style="margin-left:40px;">
							<br/><br/>
							<p><b>Head:</b><!-- name ng head ng dept. --></p>
							<p><b>Employees:</b>
								<ol>
									<li>Employee 1</li>
									<li>Employee 2</li>
								<ol>
							</p>
						</div>
					</ul><br/>
					<ul><h3><p onclick="$('#cosphy').toggle()" class="o2">Physics Department</p></h3>
						<div class="collapse off" id="cosphy" style="margin-left:40px;">
							<br/><br/>
							<p><b>Head:</b><!-- name ng head ng dept. --></p>
							<p><b>Employees:</b>
								<ol>
									<li>Employee 1</li>
									<li>Employee 2</li>
								<ol>
							</p>
						</div>
					</ul><br/>
					<ul><h3><p onclick="$('#coschem').toggle()" class="o2">Chemistry Department</p></h3>
						<div class="collapse off" id="coschem" style="margin-left:40px;">
							<br/><br/>
							<p><b>Head:</b><!-- name ng head ng dept. --></p>
							<p><b>Employees:</b>
								<ol>
									<li>Employee 1</li>
									<li>Employee 2</li>
								<ol>
							</p>
						</div>
					</ul><br/>
			</div>
		
		</div>


	</div>
</div>
	<!--border-->
	<div class="row">
		<div class=" col-md-12 col-sm-12 col-xs-12 border">  
		</div>
	</div>